// jquery is an extension of javascript and is referenced with a $
$('#actionButton').bind('click',function(){
doSomething();
});