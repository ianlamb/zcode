var y = 5;
var x = y+2;
var z = (y--)*(x/3.5)-7;
// z = 1
alert(z);