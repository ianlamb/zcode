var x = 5;
if(x > 1 && x < 10)
if(x == 5 || x != 6)
if(x === "5")

if(time < 12) {
x = "Good morning";
}else{
x = "Good afternoon";
}