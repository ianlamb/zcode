if(student.grade < 50){
fail(student);
}else if(student.grade > 90){
passWithHonours(student);
}else{
pass(student);
}