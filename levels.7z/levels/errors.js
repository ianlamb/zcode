try
{
doSomething();
}
catch(err)
{
alert(err);
}