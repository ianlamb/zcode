function myFunction(){
var x = 5;
return x;
}
var myVar = myFunction();

function myFunction(a,b){
return a * b;
}
alert(myFunction(4,3));