var number = 3.14;
var text = "John Doe";
var func = function(){};
var object = {};
var array = new Array();