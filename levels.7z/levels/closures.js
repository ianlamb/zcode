function say667() {
var num = 666;
var sayAlert = function(){ alert(num); }
num++;
return sayAlert;
}