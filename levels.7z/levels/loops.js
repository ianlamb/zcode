for(var i = 0; i < cars.length; i++){
alert(cars[i]);
}

for(x in person){
txt += person[x];
}

while(i < 5){
x += i;
i++;
}

do{
x += i;
i++;
}while(i < 5);